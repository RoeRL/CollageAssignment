﻿Public Class Form1
    Private Sub DisplayNIM_Click(sender As Object, e As EventArgs) Handles DisplayNIM.Click
        Form1.ActiveForm.Text = DisplayBox1.Text
    End Sub

    Private Sub DisplayLabel_Click(sender As Object, e As EventArgs) Handles DisplayLabel.Click
        OutputLabel.Text = DisplayBox1.Text
    End Sub

    Private Sub DisplayTB_Click(sender As Object, e As EventArgs) Handles DisplayTB.Click
        DisplayBox2.Text = DisplayBox1.Text
    End Sub

    Private Sub ChangeColor_Click(sender As Object, e As EventArgs) Handles ChangeColor.Click
        BackColor = Color.AliceBlue
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.ActiveForm.Text = DisplayBox1.Text
        OutputLabel.Text = DisplayBox1.Text
        OutputLabel.ForeColor = Color.Red
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        OutputLabel.Text = DisplayBox1.Text & " " & DisplayBox2.Text
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        OutputLabel.Text = Val(DisplayBox1.Text) + Val(DisplayBox2.Text)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        OutputLabel.Text = DisplayBox1.Text
        OutputLabel.ForeColor = Color.Yellow
        OutputLabel.BackColor = Color.Blue
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        OutputLabel.Text = (Val(DisplayBox1.Text) * Val(DisplayBox2.Text)) / 2
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        OutputLabel.Text = DisplayBox1.Text & " " & DisplayBox2.Text
        If CheckBox1.Checked Then OutputLabel.Text = Font.Bold
        If CheckBox2.Checked Then OutputLabel.Text = Font.Italic
        If CheckBox1.Checked And CheckBox2.Checked Then OutputLabel.Text = Font.Bold And Font.Italic
    End Sub
End Class
