﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.DisplayBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ProgramName = New System.Windows.Forms.Label()
        Me.DisplayNIM = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.DisplayBox2 = New System.Windows.Forms.TextBox()
        Me.OutputLabel = New System.Windows.Forms.Label()
        Me.DisplayLabel = New System.Windows.Forms.Button()
        Me.DisplayTB = New System.Windows.Forms.Button()
        Me.ChangeColor = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'DisplayBox1
        '
        Me.DisplayBox1.Location = New System.Drawing.Point(165, 51)
        Me.DisplayBox1.Name = "DisplayBox1"
        Me.DisplayBox1.Size = New System.Drawing.Size(522, 22)
        Me.DisplayBox1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 54)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Input Data"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(21, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(135, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Display Data Label 1:"
        '
        'ProgramName
        '
        Me.ProgramName.AutoSize = True
        Me.ProgramName.Location = New System.Drawing.Point(162, 90)
        Me.ProgramName.Name = "ProgramName"
        Me.ProgramName.Size = New System.Drawing.Size(10, 16)
        Me.ProgramName.TabIndex = 3
        Me.ProgramName.Text = " "
        '
        'DisplayNIM
        '
        Me.DisplayNIM.Location = New System.Drawing.Point(24, 223)
        Me.DisplayNIM.Name = "DisplayNIM"
        Me.DisplayNIM.Size = New System.Drawing.Size(135, 23)
        Me.DisplayNIM.TabIndex = 4
        Me.DisplayNIM.Text = "Tampilkan NIM"
        Me.DisplayNIM.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(21, 119)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(135, 16)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Display Data Label 2:"
        '
        'DisplayBox2
        '
        Me.DisplayBox2.Location = New System.Drawing.Point(165, 87)
        Me.DisplayBox2.Name = "DisplayBox2"
        Me.DisplayBox2.Size = New System.Drawing.Size(522, 22)
        Me.DisplayBox2.TabIndex = 6
        '
        'OutputLabel
        '
        Me.OutputLabel.AutoSize = True
        Me.OutputLabel.Location = New System.Drawing.Point(162, 119)
        Me.OutputLabel.Name = "OutputLabel"
        Me.OutputLabel.Size = New System.Drawing.Size(10, 16)
        Me.OutputLabel.TabIndex = 7
        Me.OutputLabel.Text = " "
        '
        'DisplayLabel
        '
        Me.DisplayLabel.Location = New System.Drawing.Point(165, 223)
        Me.DisplayLabel.Name = "DisplayLabel"
        Me.DisplayLabel.Size = New System.Drawing.Size(139, 23)
        Me.DisplayLabel.TabIndex = 8
        Me.DisplayLabel.Text = "Tampilkan di Label"
        Me.DisplayLabel.UseVisualStyleBackColor = True
        '
        'DisplayTB
        '
        Me.DisplayTB.Location = New System.Drawing.Point(327, 223)
        Me.DisplayTB.Name = "DisplayTB"
        Me.DisplayTB.Size = New System.Drawing.Size(175, 23)
        Me.DisplayTB.TabIndex = 9
        Me.DisplayTB.Text = "Tampilkan di Text Box"
        Me.DisplayTB.UseVisualStyleBackColor = True
        '
        'ChangeColor
        '
        Me.ChangeColor.Location = New System.Drawing.Point(537, 223)
        Me.ChangeColor.Name = "ChangeColor"
        Me.ChangeColor.Size = New System.Drawing.Size(111, 23)
        Me.ChangeColor.TabIndex = 10
        Me.ChangeColor.Text = "Change Color"
        Me.ChangeColor.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(35, 292)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(61, 23)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "#1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(107, 292)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(64, 23)
        Me.Button2.TabIndex = 12
        Me.Button2.Text = "#2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(179, 292)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(64, 23)
        Me.Button3.TabIndex = 13
        Me.Button3.Text = "#3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(252, 292)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(64, 23)
        Me.Button4.TabIndex = 14
        Me.Button4.Text = "#4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(409, 292)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(64, 23)
        Me.Button6.TabIndex = 16
        Me.Button6.Text = "#6"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(324, 292)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(64, 23)
        Me.Button5.TabIndex = 15
        Me.Button5.Text = "#5"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(35, 337)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(61, 23)
        Me.Button7.TabIndex = 17
        Me.Button7.Text = "#7"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(107, 337)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(64, 23)
        Me.Button8.TabIndex = 18
        Me.Button8.Text = "#8"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(179, 337)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(64, 23)
        Me.Button9.TabIndex = 19
        Me.Button9.Text = "#9"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(252, 337)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(72, 23)
        Me.Button10.TabIndex = 20
        Me.Button10.Text = "#10"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(332, 337)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(72, 23)
        Me.Button11.TabIndex = 21
        Me.Button11.Text = "#11"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(434, 337)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(72, 23)
        Me.Button12.TabIndex = 22
        Me.Button12.Text = "#12"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(524, 294)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(57, 20)
        Me.CheckBox1.TabIndex = 23
        Me.CheckBox1.Text = "Bold"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(524, 337)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(56, 20)
        Me.CheckBox2.TabIndex = 24
        Me.CheckBox2.Text = "Italic"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(861, 514)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ChangeColor)
        Me.Controls.Add(Me.DisplayTB)
        Me.Controls.Add(Me.DisplayLabel)
        Me.Controls.Add(Me.OutputLabel)
        Me.Controls.Add(Me.DisplayBox2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DisplayNIM)
        Me.Controls.Add(Me.ProgramName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DisplayBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DisplayBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ProgramName As Label
    Friend WithEvents DisplayNIM As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents DisplayBox2 As TextBox
    Friend WithEvents OutputLabel As Label
    Friend WithEvents DisplayLabel As Button
    Friend WithEvents DisplayTB As Button
    Friend WithEvents ChangeColor As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
End Class
